import React, { Component } from 'react';

export default class CreatePasswordPage extends Component {
    render() {
        return( 
            <div>Scoop Diddy Poop</div>
        );
    }
}
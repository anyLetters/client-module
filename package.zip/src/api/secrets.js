export const API_TOKENS = {
    dadata: '50b2734914e41cfb0812e945cdaaec2fd1ea6d88'
};

const productionEnvironment = 'prod';

export const URL = {
    [productionEnvironment === 'test' ? 'dev' : 'prod']: { api: 'https://api.credit.club', bucket: 'creditclub' },
    [productionEnvironment === 'test' ? 'prod' : 'dev']: { api: 'https://test.api.credit.club', bucket: 'creditclub-test' },
};

export const auth = {
    base64: 'YnJvd3NlcjoxMjM0NTY=',
    url: {
        [productionEnvironment === 'test' ? 'dev' : 'prod']: 'https://api.credit.club/uaa/oauth/token',
        [productionEnvironment === 'test' ? 'prod' : 'dev']: 'https://test.api.credit.club/uaa/oauth/token'
    }
};